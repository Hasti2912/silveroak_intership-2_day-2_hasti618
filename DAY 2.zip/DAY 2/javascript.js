var a=confirm("are you sure?");
if(a==true)
{
    alert("user accepted");
}
else
{
    alert("user not accepted");
}